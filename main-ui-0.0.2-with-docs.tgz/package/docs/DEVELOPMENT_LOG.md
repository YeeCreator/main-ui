# DEVELOPMENT_LOG

## 2026-08-23 · 0.0.2 本地版本包

1. 将 package version 从 `0.0.1` 更新为 `0.0.2`。
2. 通过 `pnpm typecheck`、`pnpm test`、`pnpm build` 验证。
3. 使用 `pnpm pack` 生成 `main-ui-0.0.2.tgz`，用于下游本地版本化安装。
4. 通过 relay updates outbox 向 autodo、complex-system-gallery、matheshop、scene-studio、yeegames 发布升级通知。
5. 本次采用本地 `.tgz` 分发，不等同于 npm registry 发布；下游升级为自愿、显式操作。

## 2026-04-30

完成 `main-ui` 从旧 React 壳层组件库到 Vue3 + core 工作台内核的首轮开发。

变更摘要：

1. 删除旧 React 源码、旧 demo 源码、旧 docs demo 与旧 demo-dist。
2. 包名改为 `main-ui`，移除 React peer/runtime 依赖。
3. 新增 `src/core/`：类型模型、layout helpers、reducer、registry、runtime、persistence。
4. 新增 `src/vue/`：runtime、provider、composables、WorkbenchShell、split renderer、leaf group、overlay layer、样式。
5. 新增 `src/adapters/` 与 `src/tokens/`。
6. 新增 Vue demo 与 host profile fixture。
7. 新增 core 单元测试。
8. 同步 README、API 手册、开发者指南、用户手册。

阶段 K/L 追加摘要：

1. 抽离 `demo/src/runtime/hostProfiles.ts`，集中维护 demo 与首批宿主 fixture。
2. 增加 `external-mount-demo`，通过 `EditorMountAdapter` 验证非 Vue 内容挂载路径。
3. 为 `matheshop-profile` 的 canvas placeholder 增加 pointer/focus 可观察反馈。
4. 增加 `tests/core/hostProfiles.test.ts`，校验 workspace/editor/default open request 的一致性。
5. 新增 [HOST_ADAPTER_GUIDE.md](HOST_ADAPTER_GUIDE.md) 记录 autodo-app、matheshop、yeegames 的接入草案。
6. 新增 [HOST_PROFILE_VALIDATION.md](HOST_PROFILE_VALIDATION.md) 记录阶段 K 验证范围、步骤和结论。
7. 扩写 README、API 手册、开发者指南、用户手册，完成阶段 L 文档同步。

Autodo 承接反馈补齐摘要：

1. Vue renderer 增加轻量 `IconToken` 渲染层，支持 workspace/editor descriptor 使用 `database`、`table`、`detail`、`graph`、`tex`、`settings` 等稳定图标 token。
2. Activity bar 增加底部 settings 入口，可把宿主注册的设置 editor 作为 overlay 打开。
3. Leaf tab group 补齐 `＋` editor selector、`↺` reopen recently closed、四向 split、close leaf 与 maximize/restore controls。
4. Status bar 改为 VSCode 式蓝色状态栏，显示设置入口、workspace/group/tab/theme 状态以及主题/布局快捷操作。
5. 默认 CSS 从 demo card 风格调整为更平直紧凑的 workbench 风格。
6. 空 leaf group 改为真正空白态，不再自动渲染推荐 editor launcher；宿主需通过该 leaf 顶部的 `＋` 明确打开 editor。

验证记录：

1. `pnpm typecheck` 通过。
2. `pnpm test` 通过，覆盖 core reducer 与 host profile fixture。
3. `pnpm build` 通过。
4. `pnpm demo:build` 通过。
5. VS Code 内置浏览器验证通过：Demo、external mount adapter、Matheshop pointer canvas、Settings overlay、Yeegames game-session 多实例均可交互。
6. VS Code 内置浏览器验证 autodo-app 承接版通过：activity bar `⚙`、status bar `⚙` 与 leaf `＋` selector 均可打开 settings overlay。

已知说明：

1. 阶段 H 的完整 command palette、菜单和快捷键映射未纳入本轮用户指定阶段。
2. 阶段 K 的真实宿主适配代码未纳入本轮，只完成中性 fixture 与接入草案验证。
3. 若 pnpm 对 `demo:dev` 脚本解析异常，可直接用本地 Vite 绝对路径启动 demo。

## 2026-05-01

新增 `viewport-2d-kit` 作为 editor foundation 的 demo 验证路径。

变更摘要：

1. `main-ui` demo 增加 `ViewportFoundationEditor.vue`，通过 `viewport-2d-kit/vue` 渲染可平移、缩放和 fit 的中性 2D 视口。
2. `hostProfiles.ts` 增加 `viewport-foundation` editor kind，并用于 `autodo-profile`、`matheshop-profile`、`yeegames-profile` 的图谱、公式画布与棋盘底座 fixture。
3. demo Vite 配置增加 `viewport-2d-kit` 源码 alias，保持 `main-ui/core` 不依赖 viewport 包。
4. README、用户手册、host adapter 草案与 host profile 验证记录同步到 viewport foundation 口径。
